#!/usr/bin/env python3
"""
Inference script for Mistral Reasoning Model fine-tuned with custom 4-bit quantization + RAG
Interactive chat interface for testing the model
"""

import sys
import torch
from pathlib import Path
from typing import Tuple, List
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from peft import PeftModel

class MistralInference:
    """Interactive inference with fine-tuned Mistral 4-bit model + RAG"""
    
    def __init__(self, 
                 base_model_name: str = "mistralai/Mistral-7B-Instruct-v0.3",
                 lora_model_path: str = "models/checkpoints/final_model",
                 use_merged: bool = False,
                 merged_model_path: str = "models/checkpoints/final_model_merged"):
        
        self.base_model_name = base_model_name
        self.lora_model_path = Path(lora_model_path)
        self.merged_model_path = Path(merged_model_path)
        self.use_merged = use_merged
        
        self.model = None
        self.tokenizer = None
        self.rag = None
        
        print("🚀 Mistral Reasoning Model Inference Engine")
        print(f"   Base Model: {base_model_name}")
        
        # Try to load merged model first if it exists
        if self.merged_model_path.exists() and not use_merged:
            print(f"   LoRA Adapters: {lora_model_path}")
        elif use_merged or self.merged_model_path.exists():
            print(f"   Using merged model: {merged_model_path}")
            self.use_merged = True
        else:
            print(f"   LoRA Adapters: {lora_model_path}")
        
        # Initialize RAG if available
        try:
            from scripts.setup_rag import NativeEdgeRAGSystem
            print("📊 Initializing RAG system...")
            self.rag = NativeEdgeRAGSystem()
            print("✓ RAG ready")
        except Exception as e:
            print(f"⚠ RAG not available: {e}")
            self.rag = None
    
    def get_bnb_config(self) -> BitsAndBytesConfig:
        """Get BitsAndBytes 4-bit quantization config"""
        if torch.cuda.is_available() and torch.cuda.is_bf16_supported():
            compute_dtype = torch.bfloat16
        else:
            compute_dtype = torch.float16
        
        return BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=compute_dtype,
        )
    
    def load_model(self):
        """Load Mistral model with LoRA adapters or merged weights"""
        print(f"\n📥 Loading model...")
        
        try:
            if self.use_merged and self.merged_model_path.exists():
                # Load merged model (no quantization needed for merged)
                print(f"   Loading merged model from {self.merged_model_path}...")
                self.tokenizer = AutoTokenizer.from_pretrained(self.merged_model_path)
                self.model = AutoModelForCausalLM.from_pretrained(
                    self.merged_model_path,
                    torch_dtype=torch.float16,
                    device_map="auto"
                )
                print("✓ Merged model loaded")
            else:
                # Load base model with 4-bit quantization + LoRA adapters
                print(f"   Loading base model: {self.base_model_name}")
                bnb_config = self.get_bnb_config()
                
                self.tokenizer = AutoTokenizer.from_pretrained(self.base_model_name, use_fast=True)
                if self.tokenizer.pad_token is None:
                    self.tokenizer.pad_token = self.tokenizer.eos_token
                
                self.model = AutoModelForCausalLM.from_pretrained(
                    self.base_model_name,
                    quantization_config=bnb_config,
                    device_map="auto",
                    torch_dtype=torch.float16,
                    trust_remote_code=True
                )
                print("   ✓ Base model loaded with 4-bit quantization")
                
                # Load LoRA adapters
                if self.lora_model_path.exists():
                    print(f"   Loading LoRA adapters from {self.lora_model_path}...")
                    self.model = PeftModel.from_pretrained(self.model, self.lora_model_path)
                    print("   ✓ LoRA adapters loaded")
                else:
                    print(f"   ⚠ LoRA adapters not found at {self.lora_model_path}")
                    print(f"   Using base model only")
            
            self.model.eval()
            print("✓ Model ready for inference")
            
        except Exception as e:
            print(f"❌ Failed to load model: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)
    
    def retrieve_context(self, query: str, k: int = 3) -> str:
        """Retrieve RAG context if available"""
        if not self.rag:
            return ""
        
        try:
            results = self.rag.retrieve_context(query, k=k)
            if not results:
                return ""
            
            context = "## Reference Information\n"
            for i, (doc, similarity, source) in enumerate(results, 1):
                context += f"\n[{i}] {source.upper()} (relevance: {similarity:.2f}%)\n"
                doc_preview = doc[:300] + "..." if len(doc) > 300 else doc
                context += f"→ {doc_preview}\n"
            
            return context
        except Exception as e:
            print(f"⚠ RAG retrieval failed: {e}")
            return ""
    
    def generate_response(self, query: str, max_tokens: int = 512, temperature: float = 0.7) -> Tuple[str, str]:
        """Generate response with optional RAG context"""
        
        if self.model is None:
            self.load_model()
        
        # Retrieve context
        context = self.retrieve_context(query)
        
        # Build prompt in Mistral [INST] format
        if context:
            system_prompt = """You are a Dell NativeEdge expert engineer. 
Answer the following question accurately and concisely based on the reference information provided.

Use the reference information to support your answer, but feel free to add context from your training."""
            
            full_prompt = f"""{system_prompt}

Reference Information:
{context}

[INST] {query} [/INST]"""
        else:
            full_prompt = f"""[INST] You are a Dell NativeEdge expert engineer. 
Answer the following question about Dell NativeEdge architecture, blueprints, operations, and troubleshooting.

{query} [/INST]"""
        
        # Tokenize
        inputs = self.tokenizer(full_prompt, return_tensors="pt").to(self.model.device)
        input_length = inputs['input_ids'].shape[1]
        
        print(f"\n💭 Generating response (max {max_tokens} tokens)...")
        
        # Generate
        try:
            with torch.no_grad():
                outputs = self.model.generate(
                    **inputs,
                    max_new_tokens=max_tokens,
                    temperature=temperature,
                    top_p=0.9,
                    do_sample=True,
                    pad_token_id=self.tokenizer.eos_token_id,
                    eos_token_id=self.tokenizer.eos_token_id,
                )
            
            # Decode only the generated part
            response = self.tokenizer.decode(
                outputs[0][input_length:],
                skip_special_tokens=True
            ).strip()
            
            return response, context
        
        except Exception as e:
            print(f"❌ Generation failed: {e}")
            return f"Error generating response: {e}", ""
    
    def interactive_chat(self):
        """Run interactive chat session"""
        
        print("\n" + "="*70)
        print("🤖 Dell NativeEdge Expert LLM - Interactive Chat")
        print("="*70)
        print("\nType your questions about Dell NativeEdge.")
        print("Commands:")
        print("  - Type 'exit' or 'quit' to end chat")
        print("  - Type 'context' to see retrieved information")
        print("  - Type 'help' for commands\n")
        
        self.load_model()
        
        while True:
            try:
                query = input("\n🧑 You: ").strip()
                
                if not query:
                    continue
                
                if query.lower() in ['exit', 'quit']:
                    print("\n👋 Goodbye!")
                    break
                
                if query.lower() == 'help':
                    print("""
Commands:
  exit/quit  - End conversation
  context    - Show last RAG context
  help       - Show this message
  clear      - Clear screen
  
Ask any question about Dell NativeEdge like:
  - "What is a Blueprint?"
  - "How do I deploy an application?"
  - "Error 0x016040001 - what does it mean?"
  - "Show me an example deployment"
  - "Best practices for NativeEdge"
""")
                    continue
                
                if query.lower() == 'clear':
                    import os
                    os.system('clear' if os.name == 'posix' else 'cls')
                    continue
                
                response, context = self.generate_response(query, max_tokens=512)
                
                print(f"\n🤖 Expert:")
                print("─" * 70)
                print(response)
                print("─" * 70)
                
                if context:
                    print("\n📚 Retrieved from knowledge base (use 'context' to see full)")
                    lines = context.split('\n')[:5]
                    for line in lines:
                        print(f"  {line}")
            
            except KeyboardInterrupt:
                print("\n\n👋 Chat interrupted. Goodbye!")
                break
            except Exception as e:
                print(f"❌ Error: {e}")
                continue
    
    def batch_test(self, queries: List[str] = None):
        """Test with predefined queries"""
        
        print("\n" + "="*70)
        print("🧪 Batch Testing - Mistral Reasoning NativeEdge Expert LLM")
        print("="*70)
        
        self.load_model()
        
        test_queries = queries or [
            "What is Dell NativeEdge Orchestrator?",
            "How do I create and deploy a blueprint?",
            "Explain what a Node Template is in TOSCA",
            "Error 0x016040001 - what should I do?",
            "What are the best practices for blueprint design?",
            "How do I use the NativeEdge CLI?",
            "Create a simple vSphere blueprint example",
            "What is the relationship between Blueprint and TOSCA?"
        ]
        
        for i, query in enumerate(test_queries, 1):
            print(f"\n{'─'*70}")
            print(f"Test {i}/{len(test_queries)}")
            print(f"{'─'*70}")
            print(f"\n📝 Query: {query}")
            
            response, context = self.generate_response(query, max_tokens=300)
            
            print(f"\n💬 Response:")
            print(response)
            
            if context:
                print(f"\n📚 Context retrieved: YES")
                print(context[:300] + "..." if len(context) > 300 else context)
            else:
                print(f"\n📚 Context retrieved: NO (no RAG available)")


def main():
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Mistral Reasoning Model + 4-bit Quantization Inference for NativeEdge"
    )
    parser.add_argument(
        "--base-model",
        type=str,
        default="mistralai/Mistral-7B-Instruct-v0.3",
        help="Base Mistral model name from Hugging Face"
    )
    parser.add_argument(
        "--lora",
        type=str,
        default="models/checkpoints/final_model",
        help="Path to LoRA adapters"
    )
    parser.add_argument(
        "--merged",
        action="store_true",
        help="Use merged model instead of base + LoRA"
    )
    parser.add_argument(
        "--merged-path",
        type=str,
        default="models/checkpoints/final_model_merged",
        help="Path to merged model"
    )
    parser.add_argument(
        "--query",
        type=str,
        help="Single query mode (no interactive chat)"
    )
    parser.add_argument(
        "--test",
        action="store_true",
        help="Run batch test with predefined queries"
    )
    parser.add_argument(
        "--max-tokens",
        type=int,
        default=512,
        help="Maximum tokens to generate"
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=0.7,
        help="Temperature for generation (0.0-1.0)"
    )
    
    args = parser.parse_args()
    
    # Initialize inference
    inference = MistralInference(
        base_model_name=args.base_model,
        lora_model_path=args.lora,
        use_merged=args.merged,
        merged_model_path=args.merged_path
    )
    
    # Single query mode
    if args.query:
        print(f"\n🔍 Query: {args.query}\n")
        response, context = inference.generate_response(args.query, args.max_tokens, args.temperature)
        
        print("Response:")
        print("─" * 70)
        print(response)
        print("─" * 70)
        
        if context:
            print("\nRetrieved Context:")
            print(context)
    
    # Batch test mode
    elif args.test:
        inference.batch_test()
    
    # Interactive chat mode
    else:
        inference.interactive_chat()


if __name__ == "__main__":
    main()
