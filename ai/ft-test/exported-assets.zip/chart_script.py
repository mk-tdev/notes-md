
import plotly.graph_objects as go
import json

# Data
data = {"categories": ["Python Scripts (Core)", "Python Scripts (Data)", "Documentation"], "files": [{"name": "finetune_mistral_4bit.py", "purpose": "Custom 4-bit fine-tuning", "lines": 500, "category": "Python Scripts (Core)"}, {"name": "inference_mistral_4bit.py", "purpose": "Test & deploy model", "lines": 300, "category": "Python Scripts (Core)"}, {"name": "run_pipeline_v2.py", "purpose": "Automated orchestration", "lines": 400, "category": "Python Scripts (Core)"}, {"name": "collect_data.py", "purpose": "Data collection", "lines": 250, "category": "Python Scripts (Data)"}, {"name": "prepare_dataset.py", "purpose": "Dataset preparation", "lines": 200, "category": "Python Scripts (Data)"}, {"name": "setup_rag.py", "purpose": "RAG vector database", "lines": 300, "category": "Python Scripts (Data)"}, {"name": "requirements.txt", "purpose": "Python dependencies", "lines": 30, "category": "Python Scripts (Data)"}, {"name": "00_START_HERE.md", "purpose": "Orientation guide", "lines": 363, "category": "Documentation"}, {"name": "QUICKSTART_4BIT_MISTRAL.md", "purpose": "5-minute quick start", "lines": 250, "category": "Documentation"}, {"name": "MISTRAL_4BIT_GUIDE.md", "purpose": "Complete technical guide", "lines": 500, "category": "Documentation"}, {"name": "UPDATE_SUMMARY.md", "purpose": "What's new vs old", "lines": 437, "category": "Documentation"}, {"name": "FILES_INDEX.md", "purpose": "File navigation", "lines": 350, "category": "Documentation"}, {"name": "VISUAL_OVERVIEW.md", "purpose": "Architecture diagrams", "lines": 516, "category": "Documentation"}, {"name": "REFERENCE_GUIDE.md", "purpose": "Commands & troubleshooting", "lines": 608, "category": "Documentation"}, {"name": "FINAL_SUMMARY.txt", "purpose": "Delivery checklist", "lines": 403, "category": "Documentation"}]}

# Organize files by category
category_icons = {
    "Python Scripts (Core)": "⚙️",
    "Python Scripts (Data)": "📊",
    "Documentation": "📚"
}

# Build table rows organized by category
categories_col = []
files_col = []
purpose_col = []
size_col = []

for category in data["categories"]:
    # Get files in this category
    category_files = [f for f in data["files"] if f["category"] == category]
    
    for i, file in enumerate(category_files):
        # Add category only for first file in each category
        if i == 0:
            categories_col.append(f"{category_icons[category]} {category}")
        else:
            categories_col.append("")
        
        # Add file icon based on extension
        if file["name"].endswith(".py"):
            file_icon = "🐍"
        elif file["name"].endswith(".txt"):
            file_icon = "📦"
        else:
            file_icon = "📄"
        
        files_col.append(f"{file_icon} {file['name']}")
        purpose_col.append(file["purpose"])
        size_col.append(f"{file['lines']} lines")

# Create table
fig = go.Figure(data=[go.Table(
    columnwidth=[180, 200, 200, 80],
    header=dict(
        values=['<b>Category</b>', '<b>File Name</b>', '<b>Purpose</b>', '<b>Size</b>'],
        fill_color='#1FB8CD',
        align=['left', 'left', 'left', 'right'],
        font=dict(color='white', size=13),
        height=35
    ),
    cells=dict(
        values=[categories_col, files_col, purpose_col, size_col],
        fill_color=[['#f9f9f9' if i % 2 == 0 else 'white' for i in range(len(categories_col))]],
        align=['left', 'left', 'left', 'right'],
        font=dict(color='#333333', size=11),
        height=28
    )
)])

fig.update_layout(
    title={
        "text": "Complete File Delivery Summary (15 Files)<br><span style='font-size: 18px; font-weight: normal;'>Organized by category with purposes and line counts</span>"
    }
)

# Save as PNG and SVG
fig.write_image("file_delivery_summary.png")
fig.write_image("file_delivery_summary.svg", format="svg")
