#!/usr/bin/env python3
"""
Fine-tune Mistral Reasoning Model on Dell NativeEdge dataset using custom 4-bit quantization
Local GPU training, fully open-source, no external APIs
Supports: mistralai/Mistral-7B, mistralai/Mistral-8x7B, any Mistral variant
"""

import os
import sys
from pathlib import Path
import torch
from datasets import load_dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    TrainingArguments
)
from peft import LoraConfig, get_peft_model
from trl import SFTTrainer
import json

class NativeEdgeFineTuner:
    """Fine-tune Mistral Reasoning Model on NativeEdge expertise with custom 4-bit quantization"""
    
    def __init__(self, 
                 model_name: str = "mistralai/Mistral-7B-Instruct-v0.3",
                 dataset_path: str = "data/processed/nativeedge_instructions.jsonl",
                 output_dir: str = "models/checkpoints",
                 use_4bit: bool = True,
                 bnb_4bit_quant_type: str = "nf4",
                 bnb_4bit_use_double_quant: bool = True):
        
        self.model_name = model_name
        self.dataset_path = dataset_path
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # 4-bit quantization config
        self.use_4bit = use_4bit
        self.bnb_4bit_quant_type = bnb_4bit_quant_type
        self.bnb_4bit_use_double_quant = bnb_4bit_use_double_quant
        
        print(f"🚀 NativeEdge LLM Fine-Tuner initialized")
        print(f"   Model: {model_name}")
        print(f"   Dataset: {dataset_path}")
        print(f"   Output: {output_dir}")
        print(f"   4-bit Quantization: {use_4bit}")
        print(f"   Quant Type: {bnb_4bit_quant_type}")
        print(f"   CUDA Available: {torch.cuda.is_available()}")
        if torch.cuda.is_available():
            print(f"   GPU: {torch.cuda.get_device_name(0)}")
            print(f"   VRAM: {torch.cuda.get_device_properties(0).total_memory / 1e9:.2f} GB")
    
    def get_bnb_config(self) -> BitsAndBytesConfig:
        """Create BitsAndBytes 4-bit quantization configuration"""
        print("\n⚙️  Creating BitsAndBytes 4-bit quantization config...")
        
        # Determine compute dtype
        if torch.cuda.is_available() and torch.cuda.is_bf16_supported():
            compute_dtype = torch.bfloat16
            print("   Using bfloat16 compute dtype (GPU supports bfloat16)")
        else:
            compute_dtype = torch.float16
            print("   Using float16 compute dtype")
        
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type=self.bnb_4bit_quant_type,  # "nf4" or "fp4"
            bnb_4bit_use_double_quant=self.bnb_4bit_use_double_quant,
            bnb_4bit_compute_dtype=compute_dtype,
        )
        
        print("   ✓ BitsAndBytes config created")
        return bnb_config
    
    def load_model(self):
        """Load Mistral reasoning model with custom 4-bit quantization"""
        print("\n📥 Loading Mistral reasoning model with 4-bit quantization...")
        
        # Get quantization config
        bnb_config = self.get_bnb_config()
        
        # Load tokenizer
        print(f"\n📝 Loading tokenizer from {self.model_name}...")
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.model_name,
            use_fast=True,
            trust_remote_code=True
        )
        
        # Set pad token if not already set
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
            print(f"   ✓ Set pad_token to eos_token")
        
        # Load model with 4-bit quantization
        print(f"\n🔧 Loading model with 4-bit quantization...")
        self.model = AutoModelForCausalLM.from_pretrained(
            self.model_name,
            quantization_config=bnb_config,  # <-- Custom 4-bit quantization applied here
            device_map="auto",
            torch_dtype=torch.float16,
            trust_remote_code=True,
        )
        
        print(f"   ✓ Model loaded: {self.model.model.layers[0].__class__.__name__}")
        
        # Add LoRA adapters on top of quantized model
        print("\n🔧 Adding LoRA adapters (Low-Rank Adaptation)...")
        
        lora_config = LoraConfig(
            r=16,  # LoRA rank
            lora_alpha=16,  # LoRA alpha scaling
            lora_dropout=0.05,  # Dropout for regularization
            bias="none",
            task_type="CAUSAL_LM",
            target_modules=[
                "q_proj",      # Query projection
                "k_proj",      # Key projection
                "v_proj",      # Value projection
                "o_proj",      # Output projection
                "gate_proj",   # Gate in MLP (Mistral-specific)
                "up_proj",     # Up projection in MLP
                "down_proj",   # Down projection in MLP
            ],
            use_rslora=False,
        )
        
        self.model = get_peft_model(self.model, lora_config)
        
        # Print trainable parameters info
        trainable_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        total_params = sum(p.numel() for p in self.model.parameters())
        
        print(f"   ✓ LoRA adapters configured")
        print(f"   Total parameters: {total_params:,}")
        print(f"   Trainable parameters: {trainable_params:,}")
        print(f"   Trainable %: {100 * trainable_params / total_params:.4f}%")
        
        return self.model, self.tokenizer
    
    def format_mistral_chat(self, example):
        """Format dataset in Mistral [INST] chat format"""
        if example.get("input") and example["input"].strip():
            instruction = f"{example['instruction']}\n\n{example['input']}"
        else:
            instruction = example['instruction']
        
        # Mistral instruct format: [INST] instruction [/INST] response
        text = f"[INST] {instruction} [/INST] {example['output']}"
        
        return {"text": text}
    
    def load_dataset_local(self):
        """Load JSONL dataset from local file"""
        print(f"\n📚 Loading dataset from {self.dataset_path}...")
        
        if not Path(self.dataset_path).exists():
            print(f"❌ Dataset not found at {self.dataset_path}")
            print("   Run: python scripts/collect_data.py && python scripts/prepare_dataset.py")
            sys.exit(1)
        
        # Load JSONL file
        dataset = load_dataset('json', data_files=self.dataset_path)
        
        # Split into train/eval (90/10)
        split_dataset = dataset['train'].train_test_split(test_size=0.1, seed=42)
        train_dataset = split_dataset['train']
        eval_dataset = split_dataset['test']
        
        print(f"✓ Dataset loaded successfully")
        print(f"  Training samples: {len(train_dataset):,}")
        print(f"  Validation samples: {len(eval_dataset):,}")
        print(f"  Sample format: {train_dataset[0].keys()}")
        
        return train_dataset, eval_dataset
    
    def train(self,
              num_train_epochs: int = 3,
              per_device_batch_size: int = 4,
              learning_rate: float = 2e-4,
              warmup_steps: int = 100,
              weight_decay: float = 0.01,
              logging_steps: int = 10,
              save_steps: int = 100,
              max_seq_length: int = 2048):
        """Execute fine-tuning with SFT (Supervised Fine-Tuning)"""
        
        print("\n⚙️  Configuring training parameters...")
        
        training_args = TrainingArguments(
            output_dir=str(self.output_dir),
            num_train_epochs=num_train_epochs,
            per_device_train_batch_size=per_device_batch_size,
            per_device_eval_batch_size=per_device_batch_size,
            gradient_accumulation_steps=2,  # Effective batch = per_device_batch_size * 2
            warmup_steps=warmup_steps,
            learning_rate=learning_rate,
            weight_decay=weight_decay,
            # Use bf16 if available, else fp16
            fp16=not (torch.cuda.is_available() and torch.cuda.is_bf16_supported()),
            bf16=torch.cuda.is_available() and torch.cuda.is_bf16_supported(),
            logging_steps=logging_steps,
            save_steps=save_steps,
            eval_steps=save_steps,
            save_strategy="steps",
            eval_strategy="steps",
            logging_strategy="steps",
            save_total_limit=3,  # Keep 3 best checkpoints
            load_best_model_at_end=True,
            metric_for_best_model="eval_loss",
            greater_is_better=False,
            optim="adamw_8bit",  # 8-bit optimizer saves memory
            seed=42,
            report_to=[],  # Disable wandb for local training
            max_grad_norm=1.0,
        )
        
        print(f"✓ Training arguments configured:")
        print(f"  Epochs: {num_train_epochs}")
        print(f"  Per-device batch size: {per_device_batch_size}")
        print(f"  Gradient accumulation: 2")
        print(f"  Effective batch size: {per_device_batch_size * 2}")
        print(f"  Learning rate: {learning_rate}")
        print(f"  Max sequence length: {max_seq_length}")
        print(f"  Warmup steps: {warmup_steps}")
        print(f"  Max steps: ~{(len(self.train_dataset) // (per_device_batch_size * 2)) * num_train_epochs}")
        
        # Initialize trainer
        print("\n🎓 Initializing SFT Trainer...")
        
        trainer = SFTTrainer(
            model=self.model,
            tokenizer=self.tokenizer,
            train_dataset=self.train_dataset,
            eval_dataset=self.eval_dataset,
            dataset_text_field="text",
            max_seq_length=max_seq_length,
            args=training_args,
            packing=False,  # Disable packing (better for debugging)
            formatting_func=None,  # Use dataset as-is after chat template
        )
        
        # Train!
        print("\n🚀 Starting fine-tuning...\n")
        trainer.train()
        
        print("\n✅ Training complete!")
        return trainer
    
    def save_model(self, trainer):
        """Save fine-tuned LoRA adapters"""
        print("\n💾 Saving fine-tuned LoRA adapters...")
        
        # Save the LoRA adapters
        final_adapter_path = self.output_dir / "final_model"
        self.model.save_pretrained(final_adapter_path)
        self.tokenizer.save_pretrained(final_adapter_path)
        
        print(f"✓ LoRA adapters saved to {final_adapter_path}")
        print(f"  These are lightweight adapters that work with the base model")
        
        # Save merged model (base + LoRA weights combined)
        print("\n🔄 Merging LoRA adapters with base model...")
        try:
            merged_model_path = self.output_dir / "final_model_merged"
            
            # Merge and unload LoRA
            merged_model = self.model.merge_and_unload()
            merged_model.save_pretrained(merged_model_path, safe_serialization=True)
            self.tokenizer.save_pretrained(merged_model_path)
            
            print(f"✓ Merged model saved to {merged_model_path}")
            print(f"  This contains the base model + LoRA weights combined")
            print(f"  Size: ~5-14GB (depending on base model)")
            
        except Exception as e:
            print(f"⚠ Merge failed (optional): {e}")
            print(f"  You can still use the separate LoRA adapters")
        
        return final_adapter_path
    
    def run_full_pipeline(self):
        """Execute complete fine-tuning pipeline"""
        try:
            # Step 1: Load model with 4-bit quantization
            self.load_model()
            
            # Step 2: Load dataset
            self.train_dataset, self.eval_dataset = self.load_dataset_local()
            
            # Step 3: Format datasets with Mistral chat template
            print("\n🔄 Formatting dataset with Mistral [INST] format...")
            self.train_dataset = self.train_dataset.map(
                self.format_mistral_chat,
                remove_columns=['instruction', 'input', 'output'],
                desc="Formatting training dataset"
            )
            self.eval_dataset = self.eval_dataset.map(
                self.format_mistral_chat,
                remove_columns=['instruction', 'input', 'output'],
                desc="Formatting eval dataset"
            )
            print("✓ Dataset formatted")
            
            # Step 4: Train
            trainer = self.train()
            
            # Step 5: Save
            adapter_path = self.save_model(trainer)
            
            print("\n" + "="*70)
            print("🎉 FINE-TUNING COMPLETE!")
            print("="*70)
            print(f"\nYour fine-tuned Mistral Reasoning Expert LLM is ready!")
            print(f"\n📍 Model locations:")
            print(f"   LoRA adapters: {adapter_path}")
            print(f"   Base model: {self.model_name}")
            print(f"\n📝 Next steps:")
            print(f"   1. Load and test: python scripts/inference.py")
            print(f"   2. Deploy with Ollama: ollama create nativeedge-expert -f Modelfile")
            print(f"   3. Use RAG: python scripts/setup_rag.py")
            
            return trainer
            
        except Exception as e:
            print(f"\n❌ Training failed: {str(e)}")
            import traceback
            traceback.print_exc()
            sys.exit(1)


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Fine-tune Mistral Reasoning Model on NativeEdge data")
    parser.add_argument(
        "--model",
        type=str,
        default="mistralai/Mistral-7B-Instruct-v0.3",
        help="Model name from Hugging Face Hub (default: Mistral-7B-Instruct)"
    )
    parser.add_argument(
        "--dataset",
        type=str,
        default="data/processed/nativeedge_instructions.jsonl",
        help="Path to training dataset (JSONL format)"
    )
    parser.add_argument(
        "--output",
        type=str,
        default="models/checkpoints",
        help="Output directory for checkpoints and final model"
    )
    parser.add_argument(
        "--epochs",
        type=int,
        default=3,
        help="Number of training epochs"
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=4,
        help="Per-device batch size"
    )
    parser.add_argument(
        "--lr",
        type=float,
        default=2e-4,
        help="Learning rate"
    )
    parser.add_argument(
        "--max-seq-length",
        type=int,
        default=2048,
        help="Maximum sequence length"
    )
    
    args = parser.parse_args()
    
    # Initialize fine-tuner with custom model
    finetuner = NativeEdgeFineTuner(
        model_name=args.model,
        dataset_path=args.dataset,
        output_dir=args.output
    )
    
    # Run full pipeline
    trainer = finetuner.run_full_pipeline()
