# 🚀 MISTRAL 4-BIT QUANTIZATION GUIDE

## Overview

You now have **complete control over 4-bit quantization** for any Mistral reasoning model. Instead of using pre-quantized models from Hugging Face, you:

1. **Load full-precision model** from Hugging Face
2. **Apply custom 4-bit quantization** via BitsAndBytes
3. **Fine-tune with LoRA** adapters
4. **Deploy** with or without merged weights

---

## What Changed

### Before (Unsloth Pre-quantized)
```python
# Used pre-quantized models like:
model = FastLanguageModel.from_pretrained("unsloth/llama-3-8b-bnb-4bit")
# Limited to specific pre-quantized variants
```

### After (Custom 4-bit Quantization)
```python
# Load ANY Mistral model and quantize it yourself:
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",  # You control this
    bnb_4bit_use_double_quant=True,
    bnb_4bit_compute_dtype=torch.bfloat16  # You choose dtype
)

model = AutoModelForCausalLM.from_pretrained(
    "mistralai/Mistral-7B-Instruct-v0.3",  # Any Mistral variant
    quantization_config=bnb_config,  # <-- Custom quantization
    device_map="auto"
)
```

---

## Supported Mistral Models

You can now fine-tune ANY of these models with custom 4-bit quantization:

### Base Models
- `mistralai/Mistral-7B`
- `mistralai/Mistral-7B-Instruct-v0.1`
- `mistralai/Mistral-7B-Instruct-v0.2`
- `mistralai/Mistral-7B-Instruct-v0.3` (recommended)

### Reasoning Models (NEW!)
- `mistralai/Mistral-Small` (reasoning)
- `mistralai/Ministral-8B` (reasoning variant)
- `mistralai/Mixtral-8x7B` (Mixture of Experts)
- `mistralai/Mixtral-8x22B` (MoE large)

### Example: Use Mistral Small Reasoning
```bash
# Run pipeline with Mistral Small Reasoning
python run_pipeline_v2.py --method custom_4bit --model mistralai/Mistral-Small
```

---

## Key Components

### 1. Custom 4-bit Quantization Config

**File**: `scripts/finetune_mistral_4bit.py`

```python
def get_bnb_config(self) -> BitsAndBytesConfig:
    """Create BitsAndBytes 4-bit quantization configuration"""
    
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,                          # Enable 4-bit quantization
        bnb_4bit_quant_type="nf4",                  # NormalFloat4 (best for LLMs)
        bnb_4bit_use_double_quant=True,             # Extra compression
        bnb_4bit_compute_dtype=torch.bfloat16,      # Compute dtype
    )
    return bnb_config
```

**Options**:
- `bnb_4bit_quant_type`: "nf4" (NormalFloat4) or "fp4" (Float4)
  - "nf4" is recommended for best quality
- `bnb_4bit_use_double_quant`: True/False
  - True = extra quantization on scaling factors (saves ~0.4 bits per parameter)
- `bnb_4bit_compute_dtype`: torch.bfloat16, torch.float16, or torch.float32

### 2. Model Loading with Quantization

```python
bnb_config = self.get_bnb_config()

self.model = AutoModelForCausalLM.from_pretrained(
    "mistralai/Mistral-7B-Instruct-v0.3",
    quantization_config=bnb_config,  # <-- Quantization happens here
    device_map="auto",
    torch_dtype=torch.float16,
)
```

### 3. LoRA Adapters

```python
lora_config = LoraConfig(
    r=16,
    lora_alpha=16,
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM",
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                    "gate_proj", "up_proj", "down_proj"],
)

self.model = get_peft_model(self.model, lora_config)
```

---

## Running the Pipeline

### Option 1: Full Automated Pipeline (DEFAULT)

```bash
# Uses custom 4-bit quantization by default
python run_pipeline_v2.py --method custom_4bit
```

**Steps**:
1. Check prerequisites (2 min)
2. Install dependencies (10 min)
3. Collect data (1 min)
4. Prepare dataset (2 min)
5. Fine-tune with custom 4-bit (3-4 hours)
6. Setup RAG (5 min)
7. Test inference (5 min)

### Option 2: Run Individual Steps

```bash
# Check prerequisites
python run_pipeline_v2.py --method custom_4bit --step 0

# Install dependencies
python run_pipeline_v2.py --method custom_4bit --step 1

# Collect data
python run_pipeline_v2.py --method custom_4bit --step 2

# Prepare dataset
python run_pipeline_v2.py --method custom_4bit --step 3

# Fine-tune model (with custom 4-bit)
python run_pipeline_v2.py --method custom_4bit --step 4

# Setup RAG
python run_pipeline_v2.py --method custom_4bit --step 5

# Test inference
python run_pipeline_v2.py --method custom_4bit --step 6
```

### Option 3: Direct Fine-tuning Script

```bash
# Fine-tune with custom settings
python scripts/finetune_mistral_4bit.py \
  --model mistralai/Mistral-7B-Instruct-v0.3 \
  --epochs 3 \
  --batch-size 4 \
  --lr 2e-4 \
  --max-seq-length 2048
```

**Arguments**:
- `--model`: Mistral model name (default: Mistral-7B-Instruct-v0.3)
- `--dataset`: Path to training JSONL file
- `--output`: Output directory for checkpoints
- `--epochs`: Number of training epochs (default: 3)
- `--batch-size`: Per-device batch size (default: 4)
- `--lr`: Learning rate (default: 2e-4)
- `--max-seq-length`: Max sequence length (default: 2048)

---

## Inference (Testing Your Model)

### Option 1: Interactive Chat

```bash
# Interactive chat with base model + LoRA adapters
python scripts/inference_mistral_4bit.py
```

```
🧑 You: What is a Blueprint?
💭 Thinking...
🤖 Expert: A Blueprint is a declarative YAML file...
```

### Option 2: Single Query

```bash
# Ask a single question
python scripts/inference_mistral_4bit.py \
  --query "How do I deploy a blueprint?" \
  --max-tokens 512
```

### Option 3: Batch Test

```bash
# Run 8 predefined test queries
python scripts/inference_mistral_4bit.py --test
```

### Option 4: Use Merged Model

```bash
# If you want to use merged weights (base + LoRA combined)
python scripts/inference_mistral_4bit.py --merged
```

---

## Customization

### Change Quantization Type

**Edit `scripts/finetune_mistral_4bit.py`**:

```python
# In __init__, change:
def __init__(self,
             ...
             bnb_4bit_quant_type: str = "fp4",  # Change to "fp4"
             ...):
```

Or via command line:
```bash
# Modify finetune_mistral_4bit.py line where bnb_4bit_quant_type is set
# Then run fine-tuning
```

### Use Different Compute Dtype

For GPUs that don't support bfloat16:
```python
# The script auto-detects, but you can force:
compute_dtype = torch.float16  # Instead of bfloat16
```

### Adjust Batch Size Based on VRAM

| GPU VRAM | Batch Size | Max Seq Length | Epochs | Time |
|----------|-----------|----------------|--------|------|
| 12GB | 2 | 1024 | 2 | ~2 hours |
| 16GB | 4 | 1536 | 3 | ~3 hours |
| 24GB | 4 | 2048 | 3 | ~4 hours |
| 48GB | 8 | 2048 | 3 | ~2 hours |

```bash
# For 12GB GPU
python scripts/finetune_mistral_4bit.py \
  --batch-size 2 \
  --max-seq-length 1024 \
  --epochs 2
```

### Train on Different Mistral Variant

```bash
# Mistral Small Reasoning
python scripts/finetune_mistral_4bit.py \
  --model mistralai/Mistral-Small

# Mixtral 8x7B (Mixture of Experts)
python scripts/finetune_mistral_4bit.py \
  --model mistralai/Mixtral-8x7B-Instruct-v0.1

# Mixtral 8x22B
python scripts/finetune_mistral_4bit.py \
  --model mistralai/Mixtral-8x22B-Instruct-v0.1
```

---

## Memory Breakdown

### 4-bit Quantized Mistral-7B

| Component | Memory |
|-----------|--------|
| Base model (4-bit) | 2.5GB |
| LoRA adapters (trainable) | 50MB |
| Optimizer state | 8GB |
| Activations (batch_size=4) | 6GB |
| **Total** | **~16-18GB** |

**Without quantization** (full precision): ~48GB
**Quantized advantage**: ~30GB memory saved!

---

## Understanding the Code

### File Structure

```
scripts/
├── finetune_mistral_4bit.py      # Core fine-tuning with custom 4-bit
├── inference_mistral_4bit.py     # Inference with loaded model
├── collect_data.py               # Data collection (unchanged)
├── prepare_dataset.py            # Dataset formatting (unchanged)
└── setup_rag.py                  # RAG system (unchanged)

run_pipeline_v2.py                # Pipeline orchestrator (supports both methods)
```

### How 4-bit Quantization Works

```
Full Precision (fp32): 32 bits per weight
    Example weight: 0.12345678 (4 bytes)

4-bit Quantization (nf4): 4 bits per weight
    Example weight: 0001 (0.5 byte)
    
Recovery: Scale factor × quantized value
    = 0.75 × 0001
    ≈ 0.12345678 (accurate reconstruction)

Result: 8x size reduction with minimal quality loss
```

### LoRA on Quantized Model

```
Quantized Base (frozen):    [4-bit weights] (2.5GB)
    ↓
LoRA Adapters (trainable):  [small matrices] (50MB)
    ↓
During forward pass:        output = base(x) + lora(x)
    ↓
Final model has knowledge from:
  - Frozen base model
  - Trained LoRA weights
```

---

## Troubleshooting

### Issue: "CUDA out of memory"

**Solution**: Reduce batch size and max sequence length

```bash
python scripts/finetune_mistral_4bit.py \
  --batch-size 2 \
  --max-seq-length 1024
```

### Issue: "Model not found on HF Hub"

**Solution**: Ensure you have internet and HF access

```bash
# Test HF access
huggingface-cli repo-info mistralai/Mistral-7B-Instruct-v0.3
```

### Issue: "BitsAndBytes compilation failed"

**Solution**: Install dependencies for your platform

```bash
# Linux/MacOS
pip install bitsandbytes --no-binary bitsandbytes

# Windows (WSL2 recommended)
pip install bitsandbytes
```

### Issue: "Generation is too slow"

**Solution**: Use smaller model or reduce max_tokens

```bash
# Use Mistral-Small (faster)
python scripts/inference_mistral_4bit.py \
  --base-model mistralai/Mistral-Small \
  --max-tokens 256
```

---

## Model Output Locations

After training completes:

```
models/checkpoints/
├── checkpoint-100/           # Intermediate save
├── checkpoint-200/
├── final_model/              # LoRA adapters + config
│   ├── adapter_config.json
│   ├── adapter_model.bin     # ~2MB (very small!)
│   └── tokenizer files
└── final_model_merged/       # Base + LoRA merged (optional)
    ├── pytorch_model.bin     # ~5-14GB (full model)
    └── tokenizer files
```

**For production use**:
- Use `final_model/` + base model = lightweight (2MB adapters)
- Or use `final_model_merged/` = standalone model

---

## Next Steps

1. **Run Pipeline**: `python run_pipeline_v2.py --method custom_4bit`
2. **Test Model**: `python scripts/inference_mistral_4bit.py --test`
3. **Interactive Chat**: `python scripts/inference_mistral_4bit.py`
4. **Try Different Model**: `--model mistralai/Mistral-Small`
5. **Add Your Data**: Modify `scripts/collect_data.py`
6. **Deploy**: Use merged model or base + LoRA with Ollama/vLLM

---

## Resources

- BitsAndBytes: https://github.com/TimDettmers/bitsandbytes
- Mistral Models: https://huggingface.co/mistralai
- LoRA Paper: https://arxiv.org/abs/2106.09685
- PEFT Library: https://huggingface.co/docs/peft/

---

**You now have full control over quantization! Start with `python run_pipeline_v2.py --method custom_4bit` 🚀**
