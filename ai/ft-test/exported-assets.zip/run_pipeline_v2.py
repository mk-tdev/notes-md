#!/usr/bin/env python3
"""
Complete End-to-End Pipeline for Dell NativeEdge Expert LLM
Supports: 
  - Custom 4-bit Mistral quantization (NEW)
  - Original Unsloth approach (legacy)
"""

import os
import sys
import subprocess
from pathlib import Path
import argparse
from datetime import datetime

class NativeEdgePipeline:
    """Manage complete fine-tuning pipeline"""
    
    def __init__(self, project_root: str = ".", quantization_method: str = "custom_4bit"):
        self.root = Path(project_root)
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_file = self.root / f"logs/pipeline_{self.timestamp}.log"
        self.log_file.parent.mkdir(parents=True, exist_ok=True)
        self.quantization_method = quantization_method  # "custom_4bit" or "unsloth"
        
        self.steps_completed = []
        self.steps_failed = []
        
        self._log(f"\n{'='*70}")
        self._log(f"🚀 NativeEdge Expert LLM Pipeline - {quantization_method.upper()} - {self.timestamp}")
        self._log(f"{'='*70}\n")
    
    def _log(self, message: str):
        """Log to console and file"""
        print(message)
        with open(self.log_file, 'a') as f:
            f.write(message + '\n')
    
    def _run_command(self, cmd: list, description: str) -> bool:
        """Execute command and track status"""
        self._log(f"\n📌 {description}")
        self._log(f"   Command: {' '.join(cmd)}")
        
        try:
            result = subprocess.run(
                cmd,
                cwd=self.root,
                capture_output=True,
                text=True,
                timeout=3600
            )
            
            if result.returncode != 0:
                self._log(f"   ❌ FAILED")
                self._log(f"   Error: {result.stderr}")
                self.steps_failed.append(description)
                return False
            else:
                self._log(f"   ✅ SUCCESS")
                self.steps_completed.append(description)
                return True
                
        except subprocess.TimeoutExpired:
            self._log(f"   ❌ TIMEOUT (>1 hour)")
            self.steps_failed.append(description)
            return False
        except Exception as e:
            self._log(f"   ❌ ERROR: {str(e)}")
            self.steps_failed.append(description)
            return False
    
    def step_0_prerequisites(self) -> bool:
        """Check and install prerequisites"""
        self._log(f"\n{'─'*70}")
        self._log("STEP 0: Checking Prerequisites")
        self._log(f"{'─'*70}")
        
        if sys.version_info < (3, 10):
            self._log(f"❌ Python 3.10+ required (you have {sys.version})")
            return False
        
        self._log(f"✓ Python version: {sys.version}")
        
        try:
            import torch
            if torch.cuda.is_available():
                self._log(f"✓ CUDA available: {torch.cuda.get_device_name(0)}")
                self._log(f"  VRAM: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
            else:
                self._log(f"⚠ CUDA not available - training will be SLOW on CPU")
        except ImportError:
            self._log(f"ℹ PyTorch not yet installed")
        
        dirs = [
            "data/raw", "data/processed", "data/vector_db",
            "models/checkpoints", "logs", "notebooks"
        ]
        for d in dirs:
            Path(self.root / d).mkdir(parents=True, exist_ok=True)
        
        self._log(f"✓ Created project directories")
        return True
    
    def step_1_install_dependencies(self) -> bool:
        """Install Python dependencies"""
        self._log(f"\n{'─'*70}")
        self._log("STEP 1: Installing Dependencies")
        self._log(f"{'─'*70}")
        self._log(f"Method: {self.quantization_method}")
        
        return self._run_command(
            ["pip", "install", "-r", "requirements.txt"],
            "Installing Python packages via pip"
        )
    
    def step_2_collect_data(self) -> bool:
        """Collect raw NativeEdge data"""
        self._log(f"\n{'─'*70}")
        self._log("STEP 2: Collecting Data")
        self._log(f"{'─'*70}")
        
        return self._run_command(
            ["python", "scripts/collect_data.py"],
            "Collecting Dell NativeEdge public data"
        )
    
    def step_3_prepare_dataset(self) -> bool:
        """Prepare instruction-tuning dataset"""
        self._log(f"\n{'─'*70}")
        self._log("STEP 3: Preparing Dataset")
        self._log(f"{'─'*70}")
        
        if not (self.root / "data/raw").glob("*.json"):
            self._log("❌ No raw data found - run Step 2 first")
            return False
        
        raw_files = list((self.root / "data/raw").glob("*.json"))
        if not raw_files:
            self._log("❌ No raw data files found")
            return False
        
        latest_file = sorted(raw_files)[-1]
        self._log(f"   Using: {latest_file.name}")
        
        python_code = f"""
import sys
sys.path.insert(0, '{self.root}')
from scripts.prepare_dataset import InstructionDatasetBuilder
builder = InstructionDatasetBuilder('{latest_file}')
instructions = builder.build_dataset()
builder.save_jsonl()
builder.save_csv()
"""
        
        result = subprocess.run(
            ["python", "-c", python_code],
            cwd=self.root,
            capture_output=True,
            text=True
        )
        
        if result.returncode != 0:
            self._log(f"❌ FAILED")
            self._log(f"Error: {result.stderr}")
            self.steps_failed.append("Preparing Dataset")
            return False
        
        self._log(f"✅ SUCCESS")
        self.steps_completed.append("Preparing Dataset")
        return True
    
    def step_4_finetune_model(self) -> bool:
        """Fine-tune model on NativeEdge data"""
        self._log(f"\n{'─'*70}")
        self._log("STEP 4: Fine-tuning Model")
        self._log(f"{'─'*70}")
        self._log(f"Method: {self.quantization_method}")
        
        if not (self.root / "data/processed/nativeedge_instructions.jsonl").exists():
            self._log("❌ Prepared dataset not found - run Step 3 first")
            return False
        
        # Use appropriate fine-tuning script
        if self.quantization_method == "custom_4bit":
            script = "scripts/finetune_mistral_4bit.py"
            self._log("Using custom 4-bit quantization with Mistral model")
        else:
            script = "scripts/finetune.py"
            self._log("Using Unsloth pre-quantized model")
        
        return self._run_command(
            ["python", script],
            f"Fine-tuning model with {self.quantization_method}"
        )
    
    def step_5_setup_rag(self) -> bool:
        """Setup RAG system with vector database"""
        self._log(f"\n{'─'*70}")
        self._log("STEP 5: Setting up RAG System")
        self._log(f"{'─'*70}")
        
        if not (self.root / "data/raw").glob("*.json"):
            self._log("❌ Raw data not found - run Step 2 first")
            return False
        
        raw_files = list((self.root / "data/raw").glob("*.json"))
        latest_file = sorted(raw_files)[-1]
        
        python_code = f"""
import sys
sys.path.insert(0, '{self.root}')
from scripts.setup_rag import NativeEdgeRAGSystem
rag = NativeEdgeRAGSystem()
rag.ingest_raw_data('{latest_file}')
print('\\n✅ RAG system ready!')
"""
        
        result = subprocess.run(
            ["python", "-c", python_code],
            cwd=self.root,
            capture_output=True,
            text=True
        )
        
        if result.returncode != 0:
            self._log(f"❌ FAILED")
            self._log(f"Error: {result.stderr}")
            self.steps_failed.append("Setting up RAG")
            return False
        
        self._log(f"✅ SUCCESS")
        self.steps_completed.append("Setting up RAG")
        return True
    
    def step_6_test_inference(self) -> bool:
        """Test inference with fine-tuned model + RAG"""
        self._log(f"\n{'─'*70}")
        self._log("STEP 6: Testing Inference")
        self._log(f"{'─'*70}")
        self._log(f"Method: {self.quantization_method}")
        
        # Use appropriate inference script
        if self.quantization_method == "custom_4bit":
            script = "scripts/inference_mistral_4bit.py"
            self._log("Testing with custom 4-bit Mistral inference")
        else:
            script = "scripts/inference.py"
            self._log("Testing with standard inference")
        
        return self._run_command(
            ["python", script, "--test"],
            "Testing inference with batch queries"
        )
    
    def run_full_pipeline(self, skip_steps: list = None) -> bool:
        """Execute complete pipeline"""
        
        skip_steps = skip_steps or []
        
        all_steps = [
            (0, self.step_0_prerequisites, "Prerequisites"),
            (1, self.step_1_install_dependencies, "Install Dependencies"),
            (2, self.step_2_collect_data, "Collect Data"),
            (3, self.step_3_prepare_dataset, "Prepare Dataset"),
            (4, self.step_4_finetune_model, "Fine-tune Model"),
            (5, self.step_5_setup_rag, "Setup RAG"),
            (6, self.step_6_test_inference, "Test Inference"),
        ]
        
        for step_num, step_func, step_name in all_steps:
            if step_num in skip_steps:
                self._log(f"\n⏭  SKIPPING STEP {step_num}: {step_name}")
                continue
            
            success = step_func()
            
            if not success:
                self._log(f"\n❌ PIPELINE FAILED at STEP {step_num}: {step_name}")
                self._print_summary()
                return False
        
        self._log(f"\n\n{'='*70}")
        self._log("🎉 PIPELINE COMPLETED SUCCESSFULLY!")
        self._log(f"{'='*70}\n")
        
        self._print_summary()
        return True
    
    def _print_summary(self):
        """Print execution summary"""
        self._log(f"\n{'─'*70}")
        self._log("EXECUTION SUMMARY")
        self._log(f"{'─'*70}")
        self._log(f"Quantization Method: {self.quantization_method}")
        
        if self.steps_completed:
            self._log(f"\n✅ Completed ({len(self.steps_completed)}):")
            for step in self.steps_completed:
                self._log(f"   • {step}")
        
        if self.steps_failed:
            self._log(f"\n❌ Failed ({len(self.steps_failed)}):")
            for step in self.steps_failed:
                self._log(f"   • {step}")
        
        self._log(f"\n📝 Log file: {self.log_file}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Dell NativeEdge Expert LLM - Complete Pipeline"
    )
    parser.add_argument(
        "--method",
        type=str,
        choices=["custom_4bit", "unsloth"],
        default="custom_4bit",
        help="Quantization method: 'custom_4bit' (Mistral with custom quantization) or 'unsloth' (pre-quantized)"
    )
    parser.add_argument(
        "--skip", 
        type=int, 
        nargs="+",
        help="Skip specific steps (0-6)"
    )
    parser.add_argument(
        "--step",
        type=int,
        help="Run only a specific step (0-6)"
    )
    
    args = parser.parse_args()
    
    pipeline = NativeEdgePipeline(quantization_method=args.method)
    
    if args.step is not None:
        # Run specific step
        step_methods = {
            0: pipeline.step_0_prerequisites,
            1: pipeline.step_1_install_dependencies,
            2: pipeline.step_2_collect_data,
            3: pipeline.step_3_prepare_dataset,
            4: pipeline.step_4_finetune_model,
            5: pipeline.step_5_setup_rag,
            6: pipeline.step_6_test_inference,
        }
        
        if args.step in step_methods:
            success = step_methods[args.step]()
            sys.exit(0 if success else 1)
        else:
            print(f"❌ Invalid step: {args.step}")
            sys.exit(1)
    else:
        # Run full pipeline
        skip = args.skip or []
        success = pipeline.run_full_pipeline(skip_steps=skip)
        sys.exit(0 if success else 1)
