# 🚀 QUICK START - MISTRAL 4-BIT CUSTOM QUANTIZATION

Get your Mistral reasoning model fine-tuned in 5 minutes of setup + 3-4 hours training.

## 30-Second Overview

```bash
# 1. Create project
mkdir nativeedge-expert-mistral && cd nativeedge-expert-mistral

# 2. Setup
python3.10 -m venv venv && source venv/bin/activate
mkdir -p data/{raw,processed,vector_db} models/checkpoints scripts logs

# 3. Download files (see file list below)

# 4. Install & Run
pip install -r requirements.txt
python run_pipeline_v2.py --method custom_4bit  # Everything automated

# 5. Test
python scripts/inference_mistral_4bit.py
```

---

## What's New vs Old Code

| Aspect | Old (Unsloth) | New (Custom 4-bit) |
|--------|---------------|-------------------|
| **Quantization** | Pre-quantized models | You quantize any Mistral |
| **Model Support** | Limited to `*-bnb-4bit` variants | Any Mistral model |
| **Control** | Unsloth managed | Full control via BitsAndBytesConfig |
| **Inference** | `inference.py` | `inference_mistral_4bit.py` |
| **Fine-tuning** | `finetune.py` | `finetune_mistral_4bit.py` |
| **Pipeline** | `run_pipeline.py` | `run_pipeline_v2.py --method custom_4bit` |

---

## Files You Need

### New Files (Replace These)
1. **finetune_mistral_4bit.py** - Custom 4-bit fine-tuning
2. **inference_mistral_4bit.py** - Custom 4-bit inference
3. **run_pipeline_v2.py** - Updated orchestrator (supports both methods)
4. **MISTRAL_4BIT_GUIDE.md** - This detailed guide

### Keep These (Unchanged)
1. collect_data.py - Data collection
2. prepare_dataset.py - Dataset formatting
3. setup_rag.py - RAG system
4. requirements.txt - Dependencies

---

## Quick Commands

### Run Everything (Automated)
```bash
python run_pipeline_v2.py --method custom_4bit
```

**Total time**: ~4 hours (data:1min + dataset:2min + training:3-4hrs + rag:5min + test:5min)

### Run Individual Steps
```bash
# Check GPU/Python
python run_pipeline_v2.py --method custom_4bit --step 0

# Install packages
python run_pipeline_v2.py --method custom_4bit --step 1

# Collect data
python run_pipeline_v2.py --method custom_4bit --step 2

# Prepare dataset
python run_pipeline_v2.py --method custom_4bit --step 3

# Fine-tune (main step)
python run_pipeline_v2.py --method custom_4bit --step 4

# Setup RAG
python run_pipeline_v2.py --method custom_4bit --step 5

# Test
python run_pipeline_v2.py --method custom_4bit --step 6
```

### Direct Fine-tuning
```bash
# With default settings
python scripts/finetune_mistral_4bit.py

# With custom Mistral model
python scripts/finetune_mistral_4bit.py --model mistralai/Mistral-Small

# Custom settings
python scripts/finetune_mistral_4bit.py \
  --model mistralai/Mistral-7B-Instruct-v0.3 \
  --epochs 5 \
  --batch-size 4 \
  --lr 2e-4 \
  --max-seq-length 2048
```

### Test Your Model
```bash
# Interactive chat
python scripts/inference_mistral_4bit.py

# Single query
python scripts/inference_mistral_4bit.py --query "What is a Blueprint?"

# Batch test (8 queries)
python scripts/inference_mistral_4bit.py --test

# Use merged model (if you created it)
python scripts/inference_mistral_4bit.py --merged
```

---

## What Happens Inside

### 1. Data Collection (1 minute)
```
Script: collect_data.py (unchanged)
Output: data/raw/nativeedge_raw_data_*.json (1000+ facts)
```

### 2. Dataset Preparation (2 minutes)
```
Script: prepare_dataset.py (unchanged)
Output: data/processed/nativeedge_instructions.jsonl (800 examples)
Format: {"instruction": "...", "output": "..."}
```

### 3. Fine-tuning with Custom 4-bit (3-4 hours)
```
Script: finetune_mistral_4bit.py (NEW)

Step 1: Load Mistral model (full precision)
Step 2: Apply 4-bit quantization (BitsAndBytesConfig)
Step 3: Add LoRA adapters (2.1M trainable params)
Step 4: Train on 800 examples (3 epochs)
Step 5: Save LoRA adapters + optional merged model

Output: models/checkpoints/final_model/ (LoRA adapters)
        models/checkpoints/final_model_merged/ (optional, merged)
```

### 4. RAG Setup (5 minutes)
```
Script: setup_rag.py (unchanged)
Output: data/vector_db/ (Chroma database with embeddings)
```

### 5. Inference Testing (5 minutes)
```
Script: inference_mistral_4bit.py (NEW)

Loads:
  - Base Mistral model + 4-bit quantization
  - LoRA adapters
  - Vector database for RAG
  
Runs: 8 test queries

Output: Console responses demonstrating model quality
```

---

## Memory Requirements

### For Mistral-7B with Custom 4-bit

| GPU VRAM | Batch Size | Max Seq | Time | Status |
|----------|-----------|---------|------|--------|
| 12GB | 2 | 1024 | ~2 hrs | ✅ Works |
| 16GB | 4 | 1536 | ~3 hrs | ✅ Recommended |
| 24GB | 4 | 2048 | ~4 hrs | ✅ Optimal |
| 48GB | 8 | 2048 | ~2 hrs | ✅ Very fast |

### For Mixtral-8x7B (Mixture of Experts)

| GPU VRAM | Batch Size | Max Seq | Time | Status |
|----------|-----------|---------|------|--------|
| 24GB | 2 | 1024 | ~4 hrs | ✅ Works |
| 48GB | 4 | 2048 | ~4 hrs | ✅ Recommended |
| 80GB | 8 | 2048 | ~2 hrs | ✅ Optimal |

---

## Mistral Models Available

### Small/Medium (Fast)
- `mistralai/Mistral-7B` - 7B params, fastest
- `mistralai/Mistral-7B-Instruct-v0.3` - Optimized for instructions ✅

### Reasoning (Better Quality)
- `mistralai/Mistral-Small` - Reasoning optimized
- `mistralai/Ministral-8B` - 8B reasoning variant

### Large/Powerful (Slow)
- `mistralai/Mixtral-8x7B` - 56B (8 experts × 7B)
- `mistralai/Mixtral-8x22B` - 141B (8 experts × 22B)

### Use Different Model
```bash
python scripts/finetune_mistral_4bit.py --model mistralai/Mistral-Small
```

---

## Example Output

### After Fine-tuning Completes

```
🎉 FINE-TUNING COMPLETE!

Your fine-tuned Mistral Reasoning Expert LLM is ready!

📍 Model locations:
   LoRA adapters: models/checkpoints/final_model
   Base model: mistralai/Mistral-7B-Instruct-v0.3

📝 Next steps:
   1. Load and test: python scripts/inference_mistral_4bit.py
   2. Use merged: python scripts/inference_mistral_4bit.py --merged
   3. Deploy with Ollama: ollama create nativeedge-expert -f Modelfile
```

### Interactive Chat Example

```
🧑 You: What is a Blueprint?

💭 Generating response...

🤖 Expert:
──────────────────────────────────────────────────────
A Blueprint is a declarative YAML file that defines 
infrastructure-as-code for deploying applications in 
Dell NativeEdge. It uses the TOSCA standard format:

tosca_definitions_version: nativeedge_blueprint_1_0
imports:
  - plugin:nativeedge-vsphere-plugin
topology_template:
  node_templates:
    vm:
      type: nativeedge.nodes.vsphere.VirtualMachine
      properties:
        resource_config:
          name: my-vm
          memory_mb: 4096
──────────────────────────────────────────────────────
```

---

## Troubleshooting

### "CUDA out of memory"
→ Reduce batch size: `--batch-size 2`

### "Model not found"
→ Check internet, ensure HF access: `huggingface-cli repo-info mistralai/Mistral-7B-Instruct-v0.3`

### "Slow on CPU"
→ Training on CPU takes 24+ hours. Use GPU or use smaller model.

### "BitsAndBytes error"
→ Install: `pip install --upgrade bitsandbytes`

### "Generation too slow"
→ Use smaller model or reduce `--max-tokens`

---

## Key Differences from Old Code

### Old finetune.py
```python
from unsloth import FastLanguageModel

model, tokenizer = FastLanguageModel.from_pretrained(
    model_name="unsloth/llama-3-8b-bnb-4bit"
)
```

### New finetune_mistral_4bit.py
```python
from transformers import AutoModelForCausalLM, BitsAndBytesConfig

bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_use_double_quant=True,
    bnb_4bit_compute_dtype=torch.bfloat16,
)

model = AutoModelForCausalLM.from_pretrained(
    "mistralai/Mistral-7B-Instruct-v0.3",
    quantization_config=bnb_config,  # <-- YOUR quantization
    device_map="auto",
)
```

**Key advantage**: YOU control quantization parameters!

---

## Next Steps

1. ✅ Download the 4 new files
2. ✅ Keep the 4 unchanged files  
3. ✅ Run: `python run_pipeline_v2.py --method custom_4bit`
4. ✅ Wait 4 hours
5. ✅ Test: `python scripts/inference_mistral_4bit.py`
6. ✅ Customize: Modify `scripts/collect_data.py` with your data

---

## Quick Reference

```bash
# Setup (one time)
python3.10 -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# Training
python run_pipeline_v2.py --method custom_4bit  # Full pipeline
python run_pipeline_v2.py --method custom_4bit --step 4  # Just training

# Testing
python scripts/inference_mistral_4bit.py  # Interactive
python scripts/inference_mistral_4bit.py --test  # Batch test
python scripts/inference_mistral_4bit.py --query "Your question"  # Single query

# Different models
python scripts/finetune_mistral_4bit.py --model mistralai/Mistral-Small
python scripts/finetune_mistral_4bit.py --model mistralai/Mixtral-8x7B-Instruct-v0.1

# Lower VRAM
python scripts/finetune_mistral_4bit.py --batch-size 2 --max-seq-length 1024
```

---

**You're ready! Start with `python run_pipeline_v2.py --method custom_4bit` 🚀**

For detailed info, see **MISTRAL_4BIT_GUIDE.md**
